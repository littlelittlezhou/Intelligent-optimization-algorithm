# TSP solution
import math

import self


class TabooSearch():
    def __init__(self):
        self.N = 31  # 初始化城市规模
        self.TabooL = 22  # 禁忌长度
        self.Ca = 200  # 最大候选集的个数
        self.G = 1000  # 最大迭代次数
        self.loc = [
            [1304, 2312], [3639, 1315], [4177, 2244], [3712, 1399], [3488, 1535], [3326, 1556], [3238, 1229],
            [4196, 1004], [4312, 790], [4386, 570], [3007, 1970], [2562, 1756], [2788, 1491], [2381, 1676],
            [1332, 695], [3715, 1678], [3918, 2179], [4061, 2370], [3780, 2212], [3676, 2578], [4029, 2838],
            [4263, 2931], [3429, 1908], [3507, 2367], [3394, 2643], [3439, 3201], [2935, 3240], [3140, 3550],
            [2545, 2357], [2778, 2826], [2370, 2975]]

        # 求各点之间的距离
        self.distance = [[0 for _ in range(31)] for _ in range(31)]
        for i in range(31):
            for j in range(31):
                self.distance[i][j] = round(math.sqrt(
                    pow(self.loc[i][0] - self.loc[j][0], 2) + pow(self.loc[i][1] - self.loc[j][1], 2)), 2)
                self.distance[j][i] = round(math.sqrt(
                    pow(self.loc[i][0] - self.loc[j][0], 2) + pow(self.loc[i][1] - self.loc[j][1], 2)), 2)

        # 初始解为0,1,2,3,4,...,30
        self.routeBestSoFar = []
        for i in range(self.N):
            self.routeBestSoFar.append(i)
        self.bestsofar = self.calculateDistance(route=self.routeBestSoFar, distance=self.distance)

        self.tabooList = [[0 for _ in range(31)] for _ in range(31)]

    # route为一条路径
    # 求一条路径的长度
    def calculateDistance(self, route, distance):
        dis = 0
        for i in range(1, len(route)):
            dis += distance[route[i]][route[i - 1]]
        return dis

    def print(self):
        print(self.distance)

    # 参数route表示routeBestSoFar
    # 输出routeBestSoFar的200种候选的领域路径
    # 输出200种交换的方式（没有重复）
    def randomSwap(self, route):

        # route有31个位置，我们将随机采用2-opt原则选取200对交换
        randomCouple = []
        import random
        while len(randomCouple) < self.Ca:
            firstRamd = random.randint(1, self.N - 1)  # 从下标1-30中
            twoRamd = random.randint(1, self.N - 1)
            while twoRamd == firstRamd:
                twoRamd = random.randint(1, self.N - 1)
            # 按照从小到大的顺序存储进randomCouple
            if [min(firstRamd, twoRamd), max(firstRamd, twoRamd)] not in randomCouple:
                randomCouple.append([min(firstRamd, twoRamd), max(firstRamd, twoRamd)])
        # print("选出来的200对交换次序", randomCouple, len(randomCouple))

        # 判断200个交换对有没有重合
        for i in range(self.Ca):
            for j in range(i + 1, self.Ca):
                if randomCouple[i] == randomCouple[j]:
                    print("have repeat")
        # print("not repeat")

        # 进行交换
        routesAfterChange = []
        for i in range(len(randomCouple)):
            one = randomCouple[i][0]
            two = randomCouple[i][1]
            # 交换
            T1 = route[one]
            route[one] = route[two]
            route[two] = T1
            print("交换前", route)
            routesAfterChange.append(route[:])
            # 将route在交换回来，方便下次交换
            T2 = route[one]
            route[one] = route[two]
            route[two] = T2
            print("交换后", route)

        print("routesAfterChange", routesAfterChange)

        return routesAfterChange, randomCouple

    # 首先判断route是否被禁忌，然后求没有被禁忌的最小路径和长度
    def chooseMinRoute(self, routes, randomCouple):
        # 遍历200种交换，寻找最短距离和最短路径

        shortest_route = routes[0]
        lowest_route = pow(10, 15)
        banCouple = randomCouple[0]
        for i in range(len(randomCouple)):
            r = randomCouple[i]  # r表示一对交换[x,y]
            if self.tabooList[r[0]][r[1]] == 0:
                # 如果没有被禁忌，则求其距离
                D = self.calculateDistance(routes[i], self.distance)
                if D < lowest_route:
                    shortest_route = routes[i]
                    lowest_route = D
                    banCouple = randomCouple[i]
            else:
                self.tabooList[r[0]][r[1]] -= 1

        # 找出最短路径后，更新禁忌表
        self.tabooList[banCouple[0]][banCouple[1]] = self.TabooL

        return shortest_route, lowest_route


TabooSearch = TabooSearch()
# TabooSearch.randomSwap(
#     [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30])

# 初始值
routeBestSoFar = TabooSearch.routeBestSoFar
bestsofar = TabooSearch.bestsofar
print("初始路径与初始长度", routeBestSoFar, bestsofar)
res = [bestsofar]

# 画出初始解的图
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

plt.figure(1)
for i in range(0, len(routeBestSoFar)):
    x1 = TabooSearch.loc[routeBestSoFar[i]][0]
    y1 = TabooSearch.loc[routeBestSoFar[i]][1]
    x2 = TabooSearch.loc[routeBestSoFar[i - 1]][0]
    y2 = TabooSearch.loc[routeBestSoFar[i - 1]][1]
    plt.plot([x1, x2], [y1, y2], color="r")
    if i % 2 == 0:
        plt.text(x1, y1, i, family='fantasy', fontsize=12, style='italic', color='black')
    else:
        plt.text(x1, y1, i, family='fantasy', fontsize=12, style='italic', color='blue')
    plt.text(4000, 3500, bestsofar, family='fantasy', fontsize=12, style='italic', color='blue',
             bbox=dict(facecolor="r", alpha=0.2))
plt.title("初始位置")
# plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
# plt.rcParams['axes.unicode_minus'] = False
plt.show()
plt.pause(2)
plt.close()

x_data = [1]
y_data = [bestsofar]
for i in range(TabooSearch.G):
    routesAfterChange, randomCouple = TabooSearch.randomSwap(route=routeBestSoFar)
    routeBestSoFar_T, bestsofar_T = TabooSearch.chooseMinRoute(routesAfterChange, randomCouple)
    routeBestSoFar = routeBestSoFar_T[:]
    x_data.append(i + 2)
    y_data.append(bestsofar)
    if bestsofar_T < bestsofar:
        bestsofar = bestsofar_T
        routeBestSoFar = routeBestSoFar_T[:]
print("x_data", x_data)
print("y_data", y_data)
plt.plot(x_data, y_data, color='red', linewidth=1.0, linestyle=':')
plt.title("1000次迭代的距离下降趋势图")
plt.show()

for i in range(0, len(routeBestSoFar)):
    x1 = TabooSearch.loc[routeBestSoFar[i]][0]
    y1 = TabooSearch.loc[routeBestSoFar[i]][1]
    x2 = TabooSearch.loc[routeBestSoFar[i - 1]][0]
    y2 = TabooSearch.loc[routeBestSoFar[i - 1]][1]
    plt.plot([x1, x2], [y1, y2], color="r")
    if i % 2 == 0:
        plt.text(x1, y1, i, family='fantasy', fontsize=12, style='italic', color='black')
    else:
        plt.text(x1, y1, i, family='fantasy', fontsize=12, style='italic', color='blue')
plt.title("禁忌搜索算法最优路径")
plt.text(4000, 3500, bestsofar, family='fantasy', fontsize=12, style='italic', color='blue',
             bbox=dict(facecolor="r", alpha=0.2))
plt.show()

print("ans", bestsofar)
